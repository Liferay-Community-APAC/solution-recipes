---
name: e2e-tests
description: Write, run and triage the Playwright end-to-end tests in tests/e2e of this Liferay Workspace. Use when the user asks for an automated or regression test, to turn acceptance criteria or a ticket into a test, to prove what a given user or Guest sees, to run the test suite, or to explain a failing test.
---

# End-to-End Tests

Playwright tests that check what a **real user** sees in a real browser, signed in as that user or as Guest.

## Where Things Are

| What | Where |
| --- | --- |
| Specs | `tests/e2e/*.spec.js` |
| Config | `tests/e2e/playwright.config.js` (base URL, browser, reports) |
| Sign-in and helpers | `tests/e2e/lib/liferay.js`: `signIn`, `whoAmI`, `sessionFetch` |
| Test users | `tests/e2e/test-users.properties`, git-ignored, one alias per user (`<alias>.email`, `<alias>.password`) |
| Which users the setup signs in | `E2E_PERSONAS=alias1,alias2` (default `member`) |
| Saved sessions | `tests/e2e/.auth/<alias>.json`, git-ignored |

The base URL is `LIFERAY_BASE_URL`, else `web.server.host` from `portal-ext.properties`, else `http://localhost:8080`.

## Rules

- **Never sign in as the administrator**, and never use Basic Auth to check what a user sees. An admin session or a Basic Auth request can read what the user cannot, so the test passes while the user's view is broken.
- **The admin API is for setup, cleanup and back-end checks only**: `adminAPI(baseURL)` in `lib/liferay.js`, with `E2E_ADMIN_EMAIL` and `E2E_ADMIN_PASSWORD` from the environment. Use it to create test data, delete it, or confirm a record was saved, never to decide what a user sees.
- **Never print, log or commit a password** or a file under `.auth/`. Keep credentials out of traces and reports too: never `fill()` a password in a traced test (the report shows the value), and never call an authenticated API through Playwright's `request` (the trace records its headers). Use `adminAPI` and the existing sign-in setup. To add a test user, ask the user to add the two lines to `test-users.properties` themselves, or write them there without showing them.
- **Never weaken an assertion, skip a test, or add a retry or a timeout to make a run pass.** When the product is wrong, say so and leave the test failing.

## Writing a Test

1. **Start from acceptance criteria**: a ticket, a requirement, or the user's own "it should…" sentences. Quote them in the test's title or a comment, and tag the test with the ticket or requirement id: `test('…', {tag: '@PROJ-123'}, async ({page}) => …)`.
1. **Find the real page path and selectors.** Read them from the workspace (site initializer under `client-extensions/`, fragment `index.html`, custom element source), or look at the live page with the Playwright MCP server if it is available. Never guess a selector.
1. **Sign in by persona**: `test.use({storageState: authFile('<alias>')})` in a `describe` block. A context with no saved session is Guest. To compare two users in one test, open one context each with `browser.newContext({storageState: authFile(...)})`. Add any new alias to `E2E_PERSONAS`.
1. **Prefer** `getByRole`, `getByLabel` and `getByText`, then the CSS classes the fragment defines. Use web-first assertions (`await expect(locator).toBeVisible()`), never `page.waitForTimeout`.
1. **Prove a restriction from both sides**: what the user sees, and what they must **not** see (values only another role, account or tier should see). An empty page proves nothing, so always expect at least one item the user is allowed to see.
1. **Check status codes deliberately.** In Liferay, a page closed to Guest answers `404`, not a redirect to sign-in, and a `200` alone proves nothing: assert on content.
1. **Content created through the API for a test** needs `"viewableBy": "Anyone"` (or the right roles), or only its owner can see it.
1. **To check data rather than the page**, call the API as the user with `sessionFetch(page, '/o/…')`. It sends the CSRF token Liferay requires on session-authenticated headless calls.
1. **Set up and clean up through the API; test the behaviour in the UI.** Drive the UI only for the step the test is about (a maker editing a page, a customer submitting a form).
1. **Wait for asynchronous work** (search indexing, workflow, email) with `expect.poll` or `expect(...).toPass({timeout})`, never a fixed delay.
1. **Email:** on a test environment, Liferay's mail goes to a mail catcher (such as Mailpit at `MAILPIT_URL`); search it for the run marker. Never test against real inboxes.
1. **Tag tests by area** too (`@pages`, `@content`, `@links`, `@search`, `@forms`, `@email`, `@workflow`).
1. **Tests read and don't change anything by default.** A test that must create data gives it an `e2e-` run marker (in its title or external reference code), deletes it in `afterAll`, and runs on a test or UAT environment, never production.

## Running

```bash
cd tests/e2e && npx playwright test
```

- One file: `npx playwright test smoke.spec.js`. One tag: `--grep @PROJ-123`. Watch it: `--headed` or `--ui`.
- Report the pass and fail counts and the failing tests' error lines, verbatim.

## Triaging a Failure

Open the failing test's trace (`npx playwright show-trace test-results/<test>/trace.zip`) or `playwright-report/`, then classify the failure, with the evidence:

| Class | Typical evidence | What to do |
| --- | --- | --- |
| **Product**: a real regression | The page shows what the criteria say it must not, or misses what it must | Report it. Leave the test failing. |
| **Environment** | Server down, connection refused, every test failing at once, an expired session, a feature flag off | Report it and how to fix it. Don't change the test. |
| **Test** | A selector or path that changed, a wrong assumption about the data | Propose the fix and wait for the user to agree before changing the test. |

Common Liferay causes:

- Setup stops on a first-login screen ("Verify Email Address", "Change Password", terms of use, security question): the test user signs in once by hand to complete it. Users created through the API usually get the first two.
- "Authentication failed": wrong password, the user is inactive, or the instance signs in by screen name rather than email.
- A list is empty for the test user and full for the admin: a missing permission (or Service Access Policy for Guest), not missing data.
- A bare `403` with an empty body from a headless call: a Service Access Policy, an OAuth scope, or a missing `x-csrf-token` header.
- Navigation times out over `localhost`: `web.server.host` is set, so use the public URL (`LIFERAY_BASE_URL`).
