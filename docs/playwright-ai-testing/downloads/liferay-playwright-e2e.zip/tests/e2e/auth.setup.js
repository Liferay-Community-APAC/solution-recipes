import {expect, test as setup} from '@playwright/test';

import {PERSONAS, authFile, usersFile} from './env.js';
import {readPersona, signIn} from './lib/liferay.js';

for (const alias of PERSONAS) {
	setup(`sign in as ${alias}`, async ({page}) => {
		const persona = readPersona(alias, usersFile);
		const result = await signIn(page, persona);

		expect(result.ok, result.reason).toBe(true);

		// The session must belong to this persona, not to a leftover session of another user.

		expect(result.me.email?.toLowerCase(), 'signed-in user').toBe(persona.email.toLowerCase());

		await page.context().storageState({path: authFile(alias)});
	});
}
