import {expect, test as setup} from '@playwright/test';

// A browser the test runner doesn't trace: a trace records the page and the
// form post, so it would hold the password, even with --trace on.

import {chromium} from 'playwright-core';

import {PERSONAS, authFile, usersFile} from './env.js';
import {readPersona, signIn} from './lib/liferay.js';

for (const alias of PERSONAS) {
	setup(`sign in as ${alias}`, async ({baseURL, channel, headless, ignoreHTTPSErrors, userAgent}) => {
		const browser = await chromium.launch({channel, headless});
		const context = await browser.newContext({baseURL, ignoreHTTPSErrors, userAgent});

		try {
			const page = await context.newPage();
			const persona = readPersona(alias, usersFile);
			const result = await signIn(page, persona);

			if (!result.ok) {
				await setup.info().attach('screen', {body: await page.screenshot(), contentType: 'image/png'});
			}

			expect(result.ok, result.reason).toBe(true);

			// The session must belong to this persona, not to a leftover session of another user.

			expect(result.me.email?.toLowerCase(), 'signed-in user').toBe(persona.email.toLowerCase());

			await context.storageState({path: authFile(alias)});
		}
		finally {
			await browser.close();
		}
	});
}
