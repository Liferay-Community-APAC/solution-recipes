import {expect, test} from '@playwright/test';

import {authFile} from './env.js';
import {whoAmI} from './lib/liferay.js';

test.describe('Guest', () => {

	// A browser context with no saved session is a Guest.

	test('the home page loads, signed out', async ({page}) => {
		const response = await page.goto('/');

		expect(response.status()).toBe(200);
		expect((await whoAmI(page)).signedIn).toBe(false);
	});

	test('the Control Panel answers 404 to Guest', async ({page}) => {
		const response = await page.goto('/group/control_panel/manage');

		expect(response.status()).toBe(404);
	});
});

test.describe('member', () => {
	test.use({storageState: authFile('member')});

	test('is signed in as the member', async ({page}) => {
		await page.goto('/');

		const me = await whoAmI(page);

		expect(me.signedIn).toBe(true);
		expect(me.email).not.toBeNull();
	});
});
