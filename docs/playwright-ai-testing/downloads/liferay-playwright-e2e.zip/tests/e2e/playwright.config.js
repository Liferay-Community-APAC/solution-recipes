import {defineConfig} from '@playwright/test';

import {baseURL, ngrok} from './env.js';

export default defineConfig({
	projects: [
		{name: 'setup', testMatch: /auth\.setup\.js/},
		{dependencies: ['setup'], name: 'liferay', testMatch: /.*\.spec\.js/},
	],
	reporter: [['list'], ['html', {open: 'never'}]],
	retries: process.env.CI ? 1 : 0,
	testDir: '.',
	timeout: 60_000,
	use: {
		baseURL,

		// The installed Google Chrome, so Playwright downloads no browser.
		// Set E2E_CHANNEL=chromium to use a browser from "npx playwright install chromium" instead.

		channel: process.env.E2E_CHANNEL || 'chrome',
		ignoreHTTPSErrors: true,
		screenshot: 'only-on-failure',
		trace: 'retain-on-failure',

		// A free ngrok tunnel shows browsers a warning page, but lets a non-browser user agent through.

		...(ngrok ? {userAgent: 'LiferayE2E/1.0'} : {}),
	},
	workers: 2,
});
