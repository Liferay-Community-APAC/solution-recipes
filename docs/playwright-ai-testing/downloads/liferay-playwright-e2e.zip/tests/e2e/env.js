import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

import {findWorkspace, isNgrok, resolveBaseURL} from './lib/liferay.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export const workspace = findWorkspace(here);

export const baseURL = resolveBaseURL(workspace);

export const ngrok = isNgrok(baseURL);

// Test users' credentials, git-ignored. Override with E2E_USERS_FILE.

export const usersFile = process.env.E2E_USERS_FILE || path.join(here, 'test-users.properties');

// The aliases the setup project signs in. Override with E2E_PERSONAS=alias1,alias2.

export const PERSONAS = (process.env.E2E_PERSONAS || 'member')
	.split(',')
	.map((alias) => alias.trim())
	.filter(Boolean);

const authDir = path.join(here, '.auth');

fs.mkdirSync(authDir, {recursive: true});

// The saved session of a signed-in persona. It holds live cookies: never commit it.

export function authFile(alias) {
	return path.join(authDir, `${alias}.json`);
}
