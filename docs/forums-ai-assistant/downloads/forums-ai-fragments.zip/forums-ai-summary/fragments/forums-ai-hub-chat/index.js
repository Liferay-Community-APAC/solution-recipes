/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

const root = fragmentElement.querySelector('.forums-ai-hub-chat');

/* Loads AI Hub's chat widget the way the chatbot's code in AI Hub does: its
   style sheet, then its script, with the AI Hub URL and the chatbot's code. The
   widget gets its tokens from this Liferay (an AI Hub cell). */
function loadWidget() {
	const aiHubURL = (root.dataset.aiHubUrl || '').trim().replace(/\/+$/, '');
	const chatbotExternalReferenceCode = (
		root.dataset.chatbotExternalReferenceCode || ''
	).trim();

	if (!/^https?:\/\//.test(aiHubURL) || !chatbotExternalReferenceCode) {
		return;
	}

	if (
		root.dataset.signedInOnly === 'true' &&
		!(window.Liferay && Liferay.ThemeDisplay && Liferay.ThemeDisplay.isSignedIn())
	) {
		return;
	}

	if (document.getElementById('aihub-chatbot-widget-script')) {
		return;
	}

	const link = document.createElement('link');

	link.href = aiHubURL + '/documents/d/global/index-css';
	link.rel = 'stylesheet';

	document.head.appendChild(link);

	const script = document.createElement('script');

	script.id = 'aihub-chatbot-widget-script';
	script.setAttribute('ai-hub-url', aiHubURL);
	script.setAttribute(
		'chatbot-external-reference-code',
		chatbotExternalReferenceCode
	);
	script.src = aiHubURL + '/documents/d/global/index-js';

	document.body.appendChild(script);
}

if (layoutMode === 'edit') {
	root.querySelector('.forums-ai-hub-chat__placeholder').hidden = false;
}
else if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', loadWidget);
}
else {
	loadWidget();
}
