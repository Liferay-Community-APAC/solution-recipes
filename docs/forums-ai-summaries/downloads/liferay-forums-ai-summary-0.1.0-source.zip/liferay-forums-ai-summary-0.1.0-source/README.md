# Liferay Forums AI Summary 0.1.0: Source

The source of the add-on in the [AI Discussion Summaries with AI Hub](https://liferay-community-apac.github.io/solution-recipes/forums-ai-summaries/) and [Forums Assistant with AI Hub](https://liferay-community-apac.github.io/solution-recipes/forums-ai-assistant/) recipes, for Liferay Forums 1.0.0 on Liferay DXP 2026.Q1 LTS. The recipes describe how to install and use it.

| Folder | What it is |
| --- | --- |
| `client-extensions/liferay-forums-ai-summary-batch` | The **Forums AI Summary** object and its status picklist (batch client extension) |
| `client-extensions/liferay-forums-ai-summary-etc-spring-boot` | The **summary service** (Spring Boot microservice client extension): it finds discussions that need a summary, runs the AI Hub agent, and saves the result. Its settings are in `src/main/resources/application.properties` |
| `fragments/forums-ai-summary` | The **Forums AI** fragment set: **AI Summary** and **AI Hub Chat** |
| `agents` | The workflows of the **Forums Discussion Summary** and **Forums Discussion Finder** agents, for AI Hub |

## Build

With Java 21:

```bash
./gradlew build
bash scripts/build-fragments.sh
```

The client extensions' zips are written to each one's `dist` folder, and the fragment set to `fragments/dist/liferay-forums-ai-summary-fragments.zip`. `./gradlew build` also runs the summary service's tests.

## License

Available under the same licenses as Liferay Forums: the [GNU Lesser General Public License v2.1 or later](LICENSES/LGPL-2.1-or-later.txt), or the [Liferay DXP EULA](LICENSES/LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06.txt) for Liferay subscription customers. See [LICENSING.md](LICENSING.md).
