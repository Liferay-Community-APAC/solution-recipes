Liferay Forums AI Summary: summary service

Every few minutes, this service finds forum discussions with enough replies that have gone quiet,
asks the AI Hub summary agent for a summary, and saves it in the ForumsAISummary object.

1. Deploy liferay-forums-ai-summary-etc-spring-boot.zip to Liferay (after
   liferay-forums-ai-summary-batch.zip). Liferay creates the service's OAuth application and
   writes its credentials to <liferay-home>/routes/default/liferay-forums-ai-summary-etc-spring-boot.

2. Set the AI Hub settings in the environment:

   FORUMS_AI_SUMMARY_AIHUB_URL            AI Hub's URL
   FORUMS_AI_SUMMARY_AIHUB_CLIENT_ID      OAuth 2 application of the AI Hub account (client credentials)
   FORUMS_AI_SUMMARY_AIHUB_CLIENT_SECRET  its secret, or FORUMS_AI_SUMMARY_AIHUB_CLIENT_SECRET_FILE
   FORUMS_AI_SUMMARY_AIHUB_AGENT          the agent's external reference code (default FORUMS_DISCUSSION_SUMMARY)
   FORUMS_AI_SUMMARY_SITES                forum sites' friendly URL paths (default forums)

   Optional: FORUMS_AI_SUMMARY_MIN_REPLIES (5), FORUMS_AI_SUMMARY_QUIET_PERIOD_MINUTES (10),
   FORUMS_AI_SUMMARY_INTERVAL_SECONDS (300), FORUMS_AI_SUMMARY_DAILY_LIMIT (200).

3. Start it: LIFERAY_HOME=/opt/liferay ./start.sh, or build the Docker image from the Dockerfile.
   GET http://localhost:58082/ready answers READY.
