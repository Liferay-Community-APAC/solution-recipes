/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.net.URLEncoder;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import java.time.Duration;
import java.time.Instant;

import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Runs the summary agent in the AI Hub account: one synchronous agent
 * instance, POST /o/ai-hub/v1.0/agent-instances, whose response holds the
 * agent's output.
 */
@Component
public class AIHubClient {

	public boolean isConfigured() {
		return !_url.isBlank() && !_clientId.isBlank() &&
			   !_getClientSecret().isBlank();
	}

	public String getAgentExternalReferenceCode() {
		return _agentExternalReferenceCode;
	}

	public String runAgent(String request) throws Exception {
		JSONObject body = new JSONObject();

		body.put("agentDefinitionExternalReferenceCode", _agentExternalReferenceCode);
		body.put("asynchronous", false);
		body.put("context", new JSONObject().put("request", request));

		String path = "/o/ai-hub/v1.0/agent-instances";

		// AI Hub waits up to 5 minutes for the agent, so wait a little longer.

		JsonHttp.Response response = _jsonHttp.send(
			"POST", _baseURL() + path, "Bearer " + _getToken(), body.toString(),
			"application/json", Duration.ofMinutes(6));

		if (response.status() == 401) {
			_token = null;
		}

		if (!response.ok()) {
			throw new JsonHttp.HttpException("POST", path, response.status());
		}

		return new JSONObject(
			response.body()
		).optString(
			"output", ""
		);
	}

	private String _baseURL() {
		return _url.replaceAll("/+$", "");
	}

	private String _getClientSecret() {
		if (!_clientSecret.isBlank()) {
			return _clientSecret;
		}

		if (_clientSecretFile.isBlank()) {
			return "";
		}

		try {
			return Files.readString(
				Path.of(_clientSecretFile)
			).trim();
		}
		catch (Exception exception) {
			return "";
		}
	}

	private synchronized String _getToken() throws Exception {
		if ((_token != null) &&
			_tokenExpiry.isAfter(
				Instant.now(
				).plusSeconds(
					60
				))) {

			return _token;
		}

		String form =
			"grant_type=client_credentials&client_id=" +
				URLEncoder.encode(_clientId, StandardCharsets.UTF_8) +
					"&client_secret=" +
						URLEncoder.encode(
							_getClientSecret(), StandardCharsets.UTF_8);

		JsonHttp.Response response = _jsonHttp.send(
			"POST", _baseURL() + "/o/oauth2/token", null, form,
			"application/x-www-form-urlencoded", Duration.ofSeconds(30));

		if (!response.ok()) {
			throw new JsonHttp.HttpException(
				"POST", "/o/oauth2/token", response.status());
		}

		JSONObject json = new JSONObject(response.body());

		_token = json.getString("access_token");
		_tokenExpiry = Instant.now(
		).plusSeconds(
			json.optLong("expires_in", 600)
		);

		return _token;
	}

	@Value("${forums.ai.summary.aihub.agent.external.reference.code}")
	private String _agentExternalReferenceCode;

	@Value("${forums.ai.summary.aihub.client.id}")
	private String _clientId;

	@Value("${forums.ai.summary.aihub.client.secret}")
	private String _clientSecret;

	@Value("${forums.ai.summary.aihub.client.secret.file}")
	private String _clientSecretFile;

	private final JsonHttp _jsonHttp = new JsonHttp(Duration.ofSeconds(10));
	private String _token;
	private Instant _tokenExpiry = Instant.EPOCH;

	@Value("${forums.ai.summary.aihub.url}")
	private String _url;

}
