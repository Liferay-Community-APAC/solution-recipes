/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import com.liferay.client.extension.util.spring.boot3.client.LiferayOAuth2AccessTokenManager;

import java.io.IOException;

import java.net.URLEncoder;

import java.nio.charset.StandardCharsets;

import java.time.Duration;

import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Calls the forum's Liferay with the token of this client extension's OAuth
 * application.
 */
@Component
public class LiferayClient {

	public void delete(String path) throws Exception {
		_check("DELETE", path, _send("DELETE", path, null));
	}

	public JSONObject get(String path) throws Exception {
		JsonHttp.Response response = _send("GET", path, null);

		_check("GET", path, response);

		return new JSONObject(response.body());
	}

	/**
	 * Every item of a paginated list, following its pages.
	 */
	public JSONArray getAll(String path) throws Exception {
		JSONArray items = new JSONArray();

		for (int page = 1;; page++) {
			JSONObject json = get(
				path + (path.contains("?") ? "&" : "?") + "page=" + page +
					"&pageSize=200");

			JSONArray pageItems = json.optJSONArray("items");

			if (pageItems != null) {
				pageItems.forEach(items::put);
			}

			if (page >= json.optInt("lastPage", 1)) {
				return items;
			}
		}
	}

	public JSONObject patch(String path, Object body) throws Exception {
		return _sendJSON("PATCH", path, body);
	}

	public JSONObject put(String path, Object body) throws Exception {
		return _sendJSON("PUT", path, body);
	}

	public static String encode(String value) {
		return URLEncoder.encode(value, StandardCharsets.UTF_8);
	}

	private JSONObject _sendJSON(String method, String path, Object body)
		throws Exception {

		JsonHttp.Response response = _send(method, path, body.toString());

		_check(method, path, response);

		return response.body(
		).isBlank() ? new JSONObject() : new JSONObject(response.body());
	}

	private void _check(String method, String path, JsonHttp.Response response)
		throws IOException {

		if (!response.ok()) {
			throw new JsonHttp.HttpException(method, path, response.status());
		}
	}

	private JsonHttp.Response _send(String method, String path, String body)
		throws Exception {

		String authorization =
			"Bearer " +
				_liferayOAuth2AccessTokenManager.getTokenValue(
					"liferay-forums-ai-summary-etc-spring-boot-oahs");

		return _jsonHttp.send(
			method, _baseURL + path, authorization, body, "application/json",
			Duration.ofSeconds(30));
	}

	@Value("${liferay.api.base.url}")
	private String _baseURL;

	private final JsonHttp _jsonHttp = new JsonHttp(Duration.ofSeconds(10));

	@Autowired
	private LiferayOAuth2AccessTokenManager _liferayOAuth2AccessTokenManager;

}
