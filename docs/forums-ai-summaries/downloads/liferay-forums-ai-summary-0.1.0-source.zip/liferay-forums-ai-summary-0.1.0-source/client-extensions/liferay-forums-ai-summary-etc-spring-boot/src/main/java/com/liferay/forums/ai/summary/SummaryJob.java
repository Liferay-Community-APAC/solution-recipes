/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Every few minutes: finds the forum discussions that need a summary, asks
 * the AI Hub agent for one, and saves it in ForumsAISummary. Follows the
 * forum's moderation: hides the summaries of flagged topics, makes a new
 * summary when posts are deleted or edited, and removes summaries whose
 * discussion is gone.
 */
@Component
public class SummaryJob {

	@Scheduled(
		fixedDelayString = "#{${forums.ai.summary.interval.seconds} * 1000}",
		initialDelayString = "30000"
	)
	public void run() {
		if (!_aiHubClient.isConfigured()) {
			if (!_warnedNotConfigured) {
				_log.warn(
					"AI Hub isn't configured: set FORUMS_AI_SUMMARY_AIHUB_URL, " +
						"_CLIENT_ID and _CLIENT_SECRET (or _CLIENT_SECRET_FILE)");

				_warnedNotConfigured = true;
			}

			return;
		}

		Map<Long, Map<Long, JSONObject>> summariesBySite = new HashMap<>();
		int summarizedToday = 0;

		for (String site : _sites.split(",")) {
			if (site.isBlank()) {
				continue;
			}

			try {
				long siteId = _liferayClient.get(
					"/o/headless-admin-user/v1.0/sites/by-friendly-url-path/" +
						LiferayClient.encode(site.trim())
				).getLong(
					"id"
				);

				Map<Long, JSONObject> summaries = _summaries(siteId);

				summariesBySite.put(siteId, summaries);
				summarizedToday += _countToday(summaries.values());
			}
			catch (Exception exception) {
				_log.error("Site " + site + ": " + _describe(exception));
			}
		}

		// The daily count survives restarts: it's at least the number of
		// summaries saved today.

		LocalDate today = LocalDate.now(ZoneOffset.UTC);

		if (!today.equals(_countDay)) {
			_countDay = today;
			_count = 0;
		}

		_count = Math.max(_count, summarizedToday);

		for (Map.Entry<Long, Map<Long, JSONObject>> entry :
				summariesBySite.entrySet()) {

			try {
				_runSite(entry.getKey(), entry.getValue());
			}
			catch (Exception exception) {
				_log.error(
					"Site " + entry.getKey() + ": " + _describe(exception));
			}
		}
	}

	private static int _countToday(Iterable<JSONObject> summaries) {
		LocalDate today = LocalDate.now(ZoneOffset.UTC);
		int count = 0;

		for (JSONObject summary : summaries) {
			Instant generatedDate = _instant(summary, "generatedDate");

			if ((generatedDate != null) &&
				today.equals(LocalDate.ofInstant(generatedDate, ZoneOffset.UTC)) &&
				!SummaryPolicy.STATUS_HIDDEN.equals(_status(summary))) {

				count++;
			}
		}

		return count;
	}

	private static String _describe(Exception exception) {
		String message = exception.getMessage();

		return exception.getClass(
		).getSimpleName() + ((message == null) ? "" : (": " + message));
	}

	private void _hide(long threadId, JSONObject summary, String reason)
		throws Exception {

		_liferayClient.patch(
			"/o/c/forumsaisummaries/" + summary.getLong("id"),
			new JSONObject(
			).put(
				"summary", ""
			).put(
				"summaryStatus",
				new JSONObject().put("key", SummaryPolicy.STATUS_HIDDEN)
			));

		_log.info("Thread " + threadId + ": summary hidden, " + reason);
	}

	private static Instant _instant(JSONObject json, String key) {
		String value = json.optString(key, "");

		return value.isBlank() ? null : Instant.parse(value);
	}

	/**
	 * When each thread's posts were last modified, for the posts modified in
	 * the last lookback hours: edits, and answers accepted or unaccepted.
	 */
	private Map<Long, Instant> _lastPostModified(long siteId, Instant now)
		throws Exception {

		Instant since = now.minus(
			Duration.ofHours(_lookbackHours)
		).truncatedTo(
			ChronoUnit.SECONDS
		);

		JSONArray items = _liferayClient.getAll(
			"/o/c/c2m0messages/scopes/" + siteId + "?filter=" +
				LiferayClient.encode("dateModified gt " + since) + "&fields=" +
					LiferayClient.encode(
						"dateModified,r_threadMessages_c_c2m0ThreadId"));

		Map<Long, Instant> lastPostModified = new HashMap<>();

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			long threadId = item.optLong("r_threadMessages_c_c2m0ThreadId", 0);
			Instant dateModified = _instant(item, "dateModified");

			if ((threadId > 0) && (dateModified != null)) {
				lastPostModified.merge(
					threadId, dateModified,
					(a, b) -> a.isAfter(b) ? a : b);
			}
		}

		return lastPostModified;
	}

	private List<Post> _posts(long siteId, long threadId) throws Exception {
		JSONArray items = _liferayClient.getAll(
			"/o/c/c2m0messages/scopes/" + siteId + "?filter=" +
				LiferayClient.encode(
					"r_threadMessages_c_c2m0ThreadId eq '" + threadId + "'") +
						"&fields=" +
							LiferayClient.encode(
								"id,body,bodyRawText,format,answer,voteTotal," +
									"r_messageReplies_c_c2m0MessageId,creator," +
										"dateCreated"));

		List<Post> posts = new ArrayList<>();

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			String text = item.optString("bodyRawText", "");

			if (text.isBlank()) {
				text = DiscussionFormatter.htmlToText(item.optString("body", ""));
			}

			JSONObject creator = item.optJSONObject("creator");

			posts.add(
				new Post(
					item.getLong("id"),
					item.optLong("r_messageReplies_c_c2m0MessageId", 0),
					(creator == null) ? "A member" :
						creator.optString("name", "A member"),
					_instant(item, "dateCreated"), text.trim(),
					item.optBoolean("answer"),
					(int)Math.round(item.optDouble("voteTotal", 0))));
		}

		return posts;
	}

	private void _remove(long threadId, JSONObject summary, String reason)
		throws Exception {

		_liferayClient.delete(
			"/o/c/forumsaisummaries/" + summary.getLong("id"));

		_log.info("Thread " + threadId + ": summary removed, " + reason);
	}

	private void _runSite(long siteId, Map<Long, JSONObject> summaries)
		throws Exception {

		Instant now = Instant.now();

		JSONArray threads = _liferayClient.getAll(
			"/o/c/c2m0threads/scopes/" + siteId + "?fields=" +
				LiferayClient.encode(
					"id,externalReferenceCode,title,question,messageCount," +
						"lastPostDate,validatedFlagCount"));

		Map<Long, Instant> lastPostModified = _lastPostModified(siteId, now);

		SummaryPolicy summaryPolicy = new SummaryPolicy(
			_minReplies, Duration.ofMinutes(_quietPeriodMinutes),
			Duration.ofMinutes(_retryMinutes));

		Set<Long> threadIds = new HashSet<>();
		boolean warnedLimit = false;

		for (int i = 0; i < threads.length(); i++) {
			JSONObject thread = threads.getJSONObject(i);

			long threadId = thread.getLong("id");

			threadIds.add(threadId);

			JSONObject summary = summaries.get(threadId);

			SummaryPolicy.Decision decision = summaryPolicy.decide(
				new SummaryPolicy.Discussion(
					_toInt(thread.opt("messageCount")),
					_instant(thread, "lastPostDate"),
					lastPostModified.get(threadId),
					_toInt(thread.opt("validatedFlagCount"))),
				(summary == null) ? null :
					new SummaryPolicy.Summary(
						summary.getLong("id"),
						_instant(summary, "lastPostDate"),
						_instant(summary, "generatedDate"), _status(summary),
						_toInt(summary.opt("messageCount"))),
				now);

			try {
				if (decision == SummaryPolicy.Decision.HIDE) {
					_hide(threadId, summary, "the topic is flagged");
				}
				else if (decision == SummaryPolicy.Decision.REMOVE) {
					_remove(threadId, summary, "too few replies");
				}
				else if ((decision == SummaryPolicy.Decision.REPLACE) ||
						 (decision == SummaryPolicy.Decision.SUMMARIZE)) {

					boolean ready = (summary != null) &&
						SummaryPolicy.STATUS_READY.equals(_status(summary));
					String reason = _waitReason(threadId, now);

					if (reason == null) {
						String status = _summarize(siteId, thread, summary);

						// The summary would keep what was edited or deleted
						// until a new one is made.

						if ((decision == SummaryPolicy.Decision.REPLACE) &&
							ready &&
							SummaryPolicy.STATUS_FAILED.equals(status)) {

							_hide(
								threadId, summary,
								"posts changed and a new summary failed");
						}
					}
					else {
						if (reason.startsWith("daily limit") && !warnedLimit) {
							_log.info(
								"Daily limit of " + _dailyLimit +
									" summaries reached; the rest wait for " +
										"tomorrow");

							warnedLimit = true;
						}

						if ((decision == SummaryPolicy.Decision.REPLACE) &&
							ready) {

							_hide(
								threadId, summary,
								"posts changed and a new summary waits for the " +
									reason);
						}
					}
				}
			}
			catch (Exception exception) {
				_log.error("Thread " + threadId + ": " + _describe(exception));
			}
		}

		// Summaries of discussions that are gone, or that this service can no
		// longer see.

		for (Map.Entry<Long, JSONObject> entry : summaries.entrySet()) {
			if (!threadIds.contains(entry.getKey())) {
				_remove(
					entry.getKey(), entry.getValue(),
					"the discussion no longer exists");
			}
		}
	}

	private static String _status(JSONObject summary) {
		Object value = summary.opt("summaryStatus");

		if (value instanceof JSONObject) {
			return ((JSONObject)value).optString("key", "");
		}

		return (value == null) ? "" : value.toString();
	}

	private Map<Long, JSONObject> _summaries(long siteId) throws Exception {
		Map<Long, JSONObject> summaries = new HashMap<>();

		JSONArray items = _liferayClient.getAll(
			"/o/c/forumsaisummaries/scopes/" + siteId);

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			summaries.put(item.getLong("threadId"), item);
		}

		return summaries;
	}

	/**
	 * @return the new summary's status: ready, skipped or failed
	 */
	private String _summarize(
			long siteId, JSONObject thread, JSONObject summary)
		throws Exception {

		long threadId = thread.getLong("id");
		List<Post> posts = _posts(siteId, threadId);

		String input = DiscussionFormatter.format(
			thread.optString("title", ""), thread.optBoolean("question"), posts,
			_maxInputChars);

		String status;
		String text = "";

		_count++;

		long start = System.currentTimeMillis();

		try {
			String output = _aiHubClient.runAgent(
				input
			).trim();

			if (output.isEmpty() || output.equals("NO_SUMMARY")) {
				status = SummaryPolicy.STATUS_SKIPPED;
			}
			else {
				status = SummaryPolicy.STATUS_READY;
				text = trimSummary(output, _maxSummaryChars);
			}

			_failedAt.remove(threadId);

			_log.info(
				"Thread " + threadId + ": " + status + " in " +
					(System.currentTimeMillis() - start) + " ms (" +
						posts.size() + " posts, " + input.length() +
							" input characters)");
		}
		catch (Exception exception) {
			status = SummaryPolicy.STATUS_FAILED;

			_failedAt.put(threadId, Instant.now());

			_log.error(
				"Thread " + threadId + ": the AI Hub agent failed: " +
					_describe(exception));
		}

		JSONObject entry = new JSONObject();

		entry.put(
			"agentExternalReferenceCode",
			_aiHubClient.getAgentExternalReferenceCode());
		// Liferay's date-time fields don't take fractions of a second.

		entry.put(
			"generatedDate",
			Instant.now(
			).truncatedTo(
				ChronoUnit.SECONDS
			).toString());
		entry.put("lastPostDate", thread.optString("lastPostDate"));

		// The thread's own count, which the policy compares to find deleted
		// replies.

		entry.put("messageCount", _toInt(thread.opt("messageCount")));
		entry.put("summary", text);
		entry.put("summaryStatus", new JSONObject().put("key", status));
		entry.put(
			"threadExternalReferenceCode",
			thread.optString("externalReferenceCode"));
		entry.put("threadId", threadId);

		// A failed run keeps the last good summary, so it's retried later.

		if (SummaryPolicy.STATUS_FAILED.equals(status) && (summary != null) &&
			SummaryPolicy.STATUS_READY.equals(_status(summary))) {

			return status;
		}

		String erc = "FORUMS_AI_SUMMARY_" + threadId;

		JSONObject saved = _liferayClient.put(
			"/o/c/forumsaisummaries/scopes/" + siteId +
				"/by-external-reference-code/" + erc,
			entry);

		if (summary == null) {

			// Readers see a summary as they see the discussion: the forum
			// gives the User role VIEW on its threads and posts.

			_liferayClient.put(
				"/o/c/forumsaisummaries/" + saved.getLong("id") + "/permissions",
				new JSONArray(
				).put(
					new JSONObject(
					).put(
						"actionIds", new JSONArray().put("VIEW")
					).put(
						"roleName", "User"
					)
				));
		}

		return status;
	}

	/**
	 * Aggregation fields, such as messageCount, come back as strings.
	 */
	private static int _toInt(Object value) {
		if (value instanceof Number) {
			return ((Number)value).intValue();
		}

		try {
			return (value == null) ? 0 :
				(int)Double.parseDouble(value.toString());
		}
		catch (NumberFormatException numberFormatException) {
			return 0;
		}
	}

	/**
	 * Cuts a summary longer than maxChars at the last sentence that fits, or
	 * at maxChars with an ellipsis when that sentence ends in the first half.
	 */
	static String trimSummary(String text, int maxChars) {
		if (text.length() <= maxChars) {
			return text;
		}

		String cut = text.substring(0, maxChars);

		int end = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf(".\n"));

		return (end > (maxChars / 2)) ? cut.substring(0, end + 1) :
			cut.trim() + "…";
	}

	/**
	 * Why a summary can't be made now, or null if it can: a run failed over a
	 * ready summary less than the retry period ago (that run isn't saved, so
	 * its retry is timed here), or the daily limit is reached.
	 */
	private String _waitReason(long threadId, Instant now) {
		Instant failedAt = _failedAt.get(threadId);

		if ((failedAt != null) &&
			failedAt.plus(
				Duration.ofMinutes(_retryMinutes)
			).isAfter(
				now
			)) {

			return "retry after a failure";
		}

		if (_count >= _dailyLimit) {
			return "daily limit";
		}

		return null;
	}

	private static final Log _log = LogFactory.getLog(SummaryJob.class);

	@Autowired
	private AIHubClient _aiHubClient;

	private int _count;
	private LocalDate _countDay;

	@Value("${forums.ai.summary.daily.limit}")
	private int _dailyLimit;

	private final Map<Long, Instant> _failedAt = new HashMap<>();

	@Autowired
	private LiferayClient _liferayClient;

	@Value("${forums.ai.summary.edit.lookback.hours}")
	private int _lookbackHours;

	@Value("${forums.ai.summary.max.input.chars}")
	private int _maxInputChars;

	@Value("${forums.ai.summary.max.summary.chars}")
	private int _maxSummaryChars;

	@Value("${forums.ai.summary.min.replies}")
	private int _minReplies;

	@Value("${forums.ai.summary.quiet.period.minutes}")
	private int _quietPeriodMinutes;

	@Value("${forums.ai.summary.retry.minutes}")
	private int _retryMinutes;

	@Value("${forums.ai.summary.sites}")
	private String _sites;

	private boolean _warnedNotConfigured;

}
