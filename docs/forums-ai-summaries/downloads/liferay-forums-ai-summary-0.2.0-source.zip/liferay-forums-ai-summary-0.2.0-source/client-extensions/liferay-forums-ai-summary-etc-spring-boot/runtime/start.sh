#!/bin/bash
# SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
# SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06

# Starts the summary service. On the Liferay machine, set LIFERAY_HOME so it finds the
# credentials Liferay wrote when liferay-forums-ai-summary-etc-spring-boot.zip was deployed.
# Configure AI Hub with FORUMS_AI_SUMMARY_AIHUB_URL, FORUMS_AI_SUMMARY_AIHUB_CLIENT_ID and
# FORUMS_AI_SUMMARY_AIHUB_CLIENT_SECRET (or FORUMS_AI_SUMMARY_AIHUB_CLIENT_SECRET_FILE). See
# README.txt.

set -eu

function main {
	cd "$(dirname "${0}")"

	if [[ -n "${LIFERAY_HOME:-}" ]]
	then
		export LIFERAY_ROUTES_CLIENT_EXTENSION="${LIFERAY_HOME}/routes/default/liferay-forums-ai-summary-etc-spring-boot"
		export LIFERAY_ROUTES_DXP="${LIFERAY_HOME}/routes/default/dxp"
	fi

	if [[ ! -d "${LIFERAY_ROUTES_CLIENT_EXTENSION:-}" ]]
	then
		echo "Set LIFERAY_HOME, or LIFERAY_ROUTES_CLIENT_EXTENSION and LIFERAY_ROUTES_DXP, to the routes Liferay wrote for this client extension. Deploy liferay-forums-ai-summary-etc-spring-boot.zip to Liferay first."

		exit 1
	fi

	exec java -XX:MaxRAMPercentage=50.0 -jar liferay-forums-ai-summary-etc-spring-boot.jar "${@}"
}

main "${@}"
