Liferay Forums AI Summary: summary service

Every few minutes, this service finds forum discussions with enough replies that have gone quiet,
and starts the Forums AI Summary workflow for each. The workflow's AI Hub agent node runs the
summary agent through Liferay's AI Hub connection, then calls this service, which saves the summary
in the ForumsAISummary object. The service keeps no AI Hub credentials.

1. Deploy liferay-forums-ai-summary-etc-spring-boot.zip to Liferay (after
   liferay-forums-ai-summary-batch.zip). Liferay creates the service's OAuth application and
   writes its credentials to <liferay-home>/routes/default/liferay-forums-ai-summary-etc-spring-boot.

2. Connect Liferay to AI Hub (Instance Settings, AI Hub), and deploy the Forums AI Summary workflow
   (workflows/forums-ai-summary.workflow.xml). Settings, in the environment:

   FORUMS_AI_SUMMARY_SITES                forum sites' friendly URL paths (default forums)
   FORUMS_AI_SUMMARY_WORKFLOW             the workflow's name (default Forums AI Summary)

   Optional: FORUMS_AI_SUMMARY_MIN_REPLIES (5), FORUMS_AI_SUMMARY_QUIET_PERIOD_MINUTES (10),
   FORUMS_AI_SUMMARY_INTERVAL_SECONDS (300), FORUMS_AI_SUMMARY_DAILY_LIMIT (200).

3. Start it: LIFERAY_HOME=/opt/liferay ./start.sh, or build the Docker image from the Dockerfile.
   GET http://localhost:58082/ready answers READY.
