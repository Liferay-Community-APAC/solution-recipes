/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.time.Instant;

/**
 * One forum post (a C2M0Message entry) as the summary needs it.
 *
 * @param parentId the post it replies to (r_messageReplies_c_c2m0MessageId), 0 for the
 *        discussion's first post and its top-level replies
 * @param text the post as plain text
 */
public record Post(
	long id, long parentId, String authorName, Instant dateCreated, String text,
	boolean answer, int voteTotal) {
}
