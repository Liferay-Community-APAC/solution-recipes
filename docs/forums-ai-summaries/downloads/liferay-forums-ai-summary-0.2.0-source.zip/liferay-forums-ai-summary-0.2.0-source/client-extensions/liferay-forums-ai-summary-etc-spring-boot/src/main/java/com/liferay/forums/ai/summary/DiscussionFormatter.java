/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns a discussion into the summary agent's input: plain text between
 * &lt;discussion&gt; tags, posts in the forum's reading order, each with its
 * number, author, date and notes (original post, reply to #n, accepted answer,
 * votes).
 *
 * <p>When the text is longer than the limit, posts are left out, keeping the
 * original post, the accepted answers and the most-voted posts first.</p>
 */
public class DiscussionFormatter {

	public static String format(
		String title, boolean question, List<Post> posts, int maxChars) {

		List<Post> ordered = readingOrder(posts);

		Map<Long, Integer> numbers = new HashMap<>();

		for (Post post : ordered) {
			numbers.put(post.id(), numbers.size() + 1);
		}

		Map<Long, String> blocks = new LinkedHashMap<>();

		for (Post post : ordered) {
			blocks.put(post.id(), _block(post, numbers));
		}

		Set<Long> kept = _keep(ordered, blocks, title, maxChars);

		StringBuilder sb = new StringBuilder();

		sb.append("<discussion>\nTitle: ");
		sb.append(_neutralize(title));
		sb.append("\nType: ");
		sb.append(question ? "question" : "discussion");

		if (ordered.stream(
			).anyMatch(
				Post::answer
			)) {

			sb.append(", has an accepted answer");
		}

		sb.append("\nPosts: ");
		sb.append(ordered.size());

		if (kept.size() < ordered.size()) {
			sb.append(" (");
			sb.append(ordered.size() - kept.size());
			sb.append(" left out for length)");
		}

		sb.append("\n\n");

		for (Post post : ordered) {
			if (kept.contains(post.id())) {
				sb.append(blocks.get(post.id()));
			}
		}

		sb.append("</discussion>");

		return sb.toString();
	}

	public static String htmlToText(String html) {
		if (html == null) {
			return "";
		}

		String text = _SCRIPT_PATTERN.matcher(
			html
		).replaceAll(
			""
		);

		text = text.replaceAll("(?i)<br\\s*/?>", "\n");
		text = text.replaceAll("(?i)</(p|div|li|h[1-6]|pre|blockquote)>", "\n");
		text = text.replaceAll("(?i)<li[^>]*>", "- ");
		text = text.replaceAll("<[^>]+>", "");

		Matcher matcher = _ENTITY_PATTERN.matcher(text);
		StringBuilder sb = new StringBuilder();

		while (matcher.find()) {
			matcher.appendReplacement(
				sb, Matcher.quoteReplacement(_decode(matcher.group(1))));
		}

		matcher.appendTail(sb);

		return sb.toString(
		).replaceAll(
			"[ \\t]+", " "
		).replaceAll(
			"\\n\\s*\\n+", "\n"
		).trim();
	}

	/**
	 * The forum's reading order: the first post, then each top-level reply by
	 * date, each followed by its own replies, depth first.
	 */
	public static List<Post> readingOrder(List<Post> posts) {
		Set<Long> ids = new HashSet<>();

		for (Post post : posts) {
			ids.add(post.id());
		}

		Map<Long, List<Post>> children = new HashMap<>();

		for (Post post : posts) {

			// A reply whose parent isn't visible is shown at the top level.

			long parentId = ids.contains(post.parentId()) ? post.parentId() : 0;

			children.computeIfAbsent(
				parentId, key -> new ArrayList<>()
			).add(
				post
			);
		}

		Comparator<Post> comparator = Comparator.comparing(
			Post::dateCreated
		).thenComparingLong(
			Post::id
		);

		for (List<Post> list : children.values()) {
			list.sort(comparator);
		}

		List<Post> ordered = new ArrayList<>();

		Set<Long> added = new HashSet<>();

		_addAll(children, 0, ordered, added);

		// Posts in a reply cycle (not expected) still appear, at the end.

		for (Post post : posts) {
			if (!added.contains(post.id())) {
				ordered.add(post);
			}
		}

		return ordered;
	}

	private static void _addAll(
		Map<Long, List<Post>> children, long parentId, List<Post> ordered,
		Set<Long> added) {

		for (Post post : children.getOrDefault(parentId, List.of())) {
			if (added.add(post.id())) {
				ordered.add(post);

				_addAll(children, post.id(), ordered, added);
			}
		}
	}

	private static String _block(Post post, Map<Long, Integer> numbers) {
		List<String> notes = new ArrayList<>();

		notes.add(
			post.dateCreated(
			).toString(
			).substring(
				0, 10
			));

		int number = numbers.get(post.id());

		if (number == 1) {
			notes.add("original post");
		}
		else if (numbers.containsKey(post.parentId())) {
			notes.add("reply to #" + numbers.get(post.parentId()));
		}

		if (post.answer()) {
			notes.add("ACCEPTED ANSWER");
		}

		if (post.voteTotal() != 0) {
			notes.add(
				"votes " + ((post.voteTotal() > 0) ? "+" : "") +
					post.voteTotal());
		}

		return "#" + number + " " + _neutralize(post.authorName()) + " (" +
			String.join(", ", notes) + "):\n" + _neutralize(post.text()) +
				"\n\n";
	}

	private static String _decode(String entity) {
		if (entity.startsWith("#x") || entity.startsWith("#X")) {
			return new String(
				Character.toChars(Integer.parseInt(entity.substring(2), 16)));
		}

		if (entity.startsWith("#")) {
			return new String(
				Character.toChars(Integer.parseInt(entity.substring(1))));
		}

		return _ENTITIES.getOrDefault(entity.toLowerCase(), "&" + entity + ";");
	}

	private static Set<Long> _keep(
		List<Post> ordered, Map<Long, String> blocks, String title,
		int maxChars) {

		Set<Long> kept = new HashSet<>();
		int budget = maxChars - title.length() - 200;

		List<Post> byPriority = new ArrayList<>(ordered);

		Post first = ordered.isEmpty() ? null : ordered.get(0);

		byPriority.sort(
			Comparator.comparing(
				(Post post) -> post != first
			).thenComparing(
				post -> !post.answer()
			).thenComparing(
				Post::voteTotal, Comparator.reverseOrder()
			).thenComparing(
				Post::dateCreated, Comparator.reverseOrder()
			));

		for (Post post : byPriority) {
			int length = blocks.get(
				post.id()
			).length();

			if ((length <= budget) || kept.isEmpty()) {
				kept.add(post.id());
				budget -= length;
			}
		}

		return kept;
	}

	/**
	 * A post must not be able to close the discussion block and write
	 * outside it.
	 */
	private static String _neutralize(String text) {
		if (text == null) {
			return "";
		}

		return _TAG_PATTERN.matcher(
			text
		).replaceAll(
			"[discussion]"
		);
	}

	private static final Map<String, String> _ENTITIES = Map.of(
		"amp", "&", "apos", "'", "gt", ">", "lt", "<", "nbsp", " ", "quot",
		"\"");

	private static final Pattern _ENTITY_PATTERN = Pattern.compile(
		"&(#\\d+|#[xX][0-9a-fA-F]+|[a-zA-Z]+);");

	private static final Pattern _SCRIPT_PATTERN = Pattern.compile(
		"(?is)<(script|style)[^>]*>.*?</\\1>");

	private static final Pattern _TAG_PATTERN = Pattern.compile(
		"(?i)<\\s*/?\\s*discussion\\s*>");

}
