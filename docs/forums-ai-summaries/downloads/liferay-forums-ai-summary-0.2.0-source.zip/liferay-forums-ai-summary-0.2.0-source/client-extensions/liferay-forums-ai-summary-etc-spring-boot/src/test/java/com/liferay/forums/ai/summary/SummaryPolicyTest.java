/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.liferay.forums.ai.summary.SummaryPolicy.Decision;
import com.liferay.forums.ai.summary.SummaryPolicy.Discussion;
import com.liferay.forums.ai.summary.SummaryPolicy.Summary;

import java.time.Duration;
import java.time.Instant;

import org.junit.jupiter.api.Test;

public class SummaryPolicyTest {

	@Test
	public void testAnswerAcceptedOrPostEditedAfterTheSummary() {
		Summary summary = _summary("ready", 6);

		// Modified after the summary, but still within the quiet period.

		assertEquals(
			Decision.NOT_QUIET_YET,
			_policy.decide(
				new Discussion(6, _LAST_POST, _NOW.minusSeconds(60), 0), summary,
				_NOW));

		assertEquals(
			Decision.REPLACE,
			_policy.decide(
				new Discussion(
					6, _LAST_POST, _SUMMARIZED.plus(Duration.ofMinutes(5)), 0),
				summary, _NOW));

		// Modified before the summary was made.

		assertEquals(
			Decision.UP_TO_DATE,
			_policy.decide(
				new Discussion(
					6, _LAST_POST, _SUMMARIZED.minus(Duration.ofMinutes(5)), 0),
				summary, _NOW));
	}

	@Test
	public void testFailedSummaryIsRetriedAfterTheRetryPeriod() {
		Summary failed = new Summary(
			1, _LAST_POST, _NOW.minus(Duration.ofMinutes(30)), "failed", 6);

		assertEquals(
			Decision.UP_TO_DATE, _policy.decide(_discussion(6), failed, _NOW));

		failed = new Summary(
			1, _LAST_POST, _NOW.minus(Duration.ofMinutes(61)), "failed", 6);

		assertEquals(
			Decision.SUMMARIZE, _policy.decide(_discussion(6), failed, _NOW));
	}

	@Test
	public void testFlaggedTopicHasNoSummary() {
		Discussion flagged = new Discussion(6, _LAST_POST, null, 1);

		assertEquals(Decision.FLAGGED, _policy.decide(flagged, null, _NOW));
		assertEquals(
			Decision.HIDE, _policy.decide(flagged, _summary("ready", 6), _NOW));
		assertEquals(
			Decision.HIDE, _policy.decide(flagged, _summary("failed", 6), _NOW));
		assertEquals(
			Decision.FLAGGED,
			_policy.decide(flagged, _summary("hidden", 6), _NOW));

		// Flagged with too few replies: still only hidden.

		assertEquals(
			Decision.HIDE,
			_policy.decide(
				new Discussion(2, _LAST_POST, null, 1), _summary("ready", 6),
				_NOW));
	}

	@Test
	public void testNewReplyAfterTheSummary() {
		Summary summary = new Summary(
			1, _LAST_POST.minus(Duration.ofHours(1)), _NOW, "ready", 6);

		assertEquals(
			Decision.SUMMARIZE, _policy.decide(_discussion(7), summary, _NOW));
	}

	@Test
	public void testNotQuietYet() {
		assertEquals(
			Decision.NOT_QUIET_YET,
			_policy.decide(
				new Discussion(6, _NOW.minus(Duration.ofMinutes(5)), null, 0),
				null, _NOW));
	}

	@Test
	public void testReplyDeleted() {
		assertEquals(
			Decision.REPLACE,
			_policy.decide(_discussion(7), _summary("ready", 8), _NOW));

		// Below the minimum: the summary goes.

		assertEquals(
			Decision.REMOVE,
			_policy.decide(_discussion(5), _summary("ready", 6), _NOW));
	}

	@Test
	public void testTooFewReplies() {

		// Five posts are the first post and four replies.

		assertEquals(
			Decision.TOO_FEW_REPLIES, _policy.decide(_discussion(5), null, _NOW));
		assertEquals(
			Decision.SUMMARIZE, _policy.decide(_discussion(6), null, _NOW));
	}

	@Test
	public void testUnflaggedTopicIsSummarizedAgain() {
		assertEquals(
			Decision.SUMMARIZE,
			_policy.decide(_discussion(6), _summary("hidden", 6), _NOW));
	}

	@Test
	public void testUpToDate() {
		assertEquals(
			Decision.UP_TO_DATE,
			_policy.decide(_discussion(6), _summary("ready", 6), _NOW));
		assertEquals(
			Decision.UP_TO_DATE,
			_policy.decide(_discussion(6), _summary("skipped", 6), _NOW));
	}

	private static Discussion _discussion(int messageCount) {
		return new Discussion(messageCount, _LAST_POST, null, 0);
	}

	private static Summary _summary(String status, int messageCount) {
		return new Summary(1, _LAST_POST, _SUMMARIZED, status, messageCount);
	}

	private static final Instant _LAST_POST = Instant.parse(
		"2026-11-08T10:00:00Z");

	private static final Instant _NOW = Instant.parse("2026-11-08T11:00:00Z");

	private static final Instant _SUMMARIZED = Instant.parse(
		"2026-11-08T10:15:00Z");

	private final SummaryPolicy _policy = new SummaryPolicy(
		5, Duration.ofMinutes(10), Duration.ofMinutes(60));

}
