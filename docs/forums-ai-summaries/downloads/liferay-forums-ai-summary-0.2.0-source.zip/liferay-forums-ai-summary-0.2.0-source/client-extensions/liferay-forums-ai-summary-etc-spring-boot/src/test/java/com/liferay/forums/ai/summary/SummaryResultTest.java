/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.json.JSONObject;

import org.junit.jupiter.api.Test;

public class SummaryResultTest {

	@Test
	public void testParseResult() {

		// The workflow context comes back with its values as strings.

		SummaryJob.Result result = SummaryJob.parseResult(
			new JSONObject(
			).put(
				"agentDefinitionExternalReferenceCode", "FORUMS_DISCUSSION_SUMMARY"
			).put(
				"forumsAISummaryLastPostDate", "2026-11-09T12:00:00Z"
			).put(
				"forumsAISummaryMessageCount", "7"
			).put(
				"forumsAISummarySiteId", "35166"
			).put(
				"forumsAISummaryThreadExternalReferenceCode", "abc"
			).put(
				"forumsAISummaryThreadId", "37926"
			).put(
				"output", "Ignored when summary is set."
			).put(
				"summary", " Mei asked how to claim a client dinner. "
			));

		assertEquals(
			"FORUMS_DISCUSSION_SUMMARY", result.agentExternalReferenceCode());
		assertEquals("2026-11-09T12:00:00Z", result.lastPostDate());
		assertEquals(7, result.messageCount());
		assertEquals(35166, result.siteId());
		assertEquals("Mei asked how to claim a client dinner.", result.text());
		assertEquals("abc", result.threadExternalReferenceCode());
		assertEquals(37926, result.threadId());

		// Without the output variable, the agent's output.

		assertEquals(
			"From output.",
			SummaryJob.parseResult(
				new JSONObject(
				).put(
					"forumsAISummarySiteId", 1
				).put(
					"forumsAISummaryThreadId", 2
				).put(
					"output", "From output."
				)
			).text());

		// A call that names no thread is ignored.

		assertNull(
			SummaryJob.parseResult(new JSONObject().put("summary", "Text")));
	}

}
