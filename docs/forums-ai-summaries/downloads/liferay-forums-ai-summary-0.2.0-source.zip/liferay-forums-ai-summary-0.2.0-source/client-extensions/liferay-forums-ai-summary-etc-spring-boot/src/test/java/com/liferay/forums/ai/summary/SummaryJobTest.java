/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SummaryJobTest {

	@Test
	public void testTrimSummary() {
		assertEquals("Short.", SummaryJob.trimSummary("Short.", 20));

		// Cut at the last sentence that fits.

		assertEquals(
			"First sentence here. Second one.",
			SummaryJob.trimSummary(
				"First sentence here. Second one. Third sentence is long.", 40));

		// No sentence ends in the second half: cut with an ellipsis.

		assertEquals(
			"One very long sentence…",
			SummaryJob.trimSummary(
				"One very long sentence without a full stop for ages", 23));
	}

}
