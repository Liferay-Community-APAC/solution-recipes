/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.io.IOException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.time.Duration;

/**
 * Small JSON-over-HTTP helper. Errors carry the method, path and status, never
 * a token or a response body that could hold one.
 */
public class JsonHttp {

	public JsonHttp(Duration connectTimeout) {
		_httpClient = HttpClient.newBuilder(
		).connectTimeout(
			connectTimeout
		).build();
	}

	public Response send(
			String method, String url, String authorization, String body,
			String contentType, Duration timeout)
		throws IOException, InterruptedException {

		HttpRequest.Builder builder = HttpRequest.newBuilder(
			URI.create(url)
		).header(
			"Accept", "application/json"
		).timeout(
			timeout
		);

		if (authorization != null) {
			builder.header("Authorization", authorization);
		}

		if (body == null) {
			builder.method(method, HttpRequest.BodyPublishers.noBody());
		}
		else {
			builder.header("Content-Type", contentType);
			builder.method(method, HttpRequest.BodyPublishers.ofString(body));
		}

		HttpResponse<String> httpResponse = _httpClient.send(
			builder.build(), HttpResponse.BodyHandlers.ofString());

		return new Response(httpResponse.statusCode(), httpResponse.body());
	}

	public record Response(int status, String body) {

		public boolean ok() {
			return (status >= 200) && (status < 300);
		}

	}

	public static class HttpException extends IOException {

		public HttpException(String method, String path, int status) {
			super(method + " " + path + " returned HTTP " + status);

			_status = status;
		}

		public int getStatus() {
			return _status;
		}

		private final int _status;

	}

	private final HttpClient _httpClient;

}
