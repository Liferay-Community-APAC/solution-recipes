/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.time.Duration;
import java.time.Instant;

/**
 * Decides what a discussion's summary needs: nothing, a new summary, or to be
 * hidden or removed because of moderation.
 *
 * The forum moderates whole topics: a validated report flags the topic, and a
 * moderator can delete a topic or a reply, or edit a post. A flagged topic has
 * no summary. A deleted reply, an edited post or a newly accepted answer makes
 * a new summary, after the quiet period. Until it's made, the old summary is
 * hidden if it can't be replaced right away, so it never keeps what moderation
 * removed.
 */
public class SummaryPolicy {

	public SummaryPolicy(int minReplies, Duration quietPeriod, Duration retry) {
		_minReplies = minReplies;
		_quietPeriod = quietPeriod;
		_retry = retry;
	}

	public Decision decide(Discussion discussion, Summary summary, Instant now) {
		if (discussion.validatedFlagCount() > 0) {
			if ((summary != null) && !STATUS_HIDDEN.equals(summary.status())) {
				return Decision.HIDE;
			}

			return Decision.FLAGGED;
		}

		if ((discussion.messageCount() - 1) < _minReplies) {
			return (summary == null) ? Decision.TOO_FEW_REPLIES :
				Decision.REMOVE;
		}

		if (discussion.lastPostDate() == null) {
			return Decision.NO_LAST_POST_DATE;
		}

		Instant lastActivity = discussion.lastPostDate();

		if ((discussion.lastPostModified() != null) &&
			discussion.lastPostModified(
			).isAfter(
				lastActivity
			)) {

			lastActivity = discussion.lastPostModified();
		}

		if (lastActivity.plus(
				_quietPeriod
			).isAfter(
				now
			)) {

			return Decision.NOT_QUIET_YET;
		}

		if ((summary == null) || STATUS_HIDDEN.equals(summary.status())) {
			return Decision.SUMMARIZE;
		}

		// A new reply.

		if ((summary.lastPostDate() == null) ||
			summary.lastPostDate(
			).isBefore(
				discussion.lastPostDate()
			)) {

			return Decision.SUMMARIZE;
		}

		// A deleted reply.

		if (summary.messageCount() != discussion.messageCount()) {
			return Decision.REPLACE;
		}

		// An edited post, or an answer accepted, after the summary was made.

		if ((discussion.lastPostModified() != null) &&
			((summary.generatedDate() == null) ||
			 summary.generatedDate(
			 ).isBefore(
				 discussion.lastPostModified()
			 ))) {

			return Decision.REPLACE;
		}

		if (STATUS_FAILED.equals(summary.status()) &&
			((summary.generatedDate() == null) ||
			 !summary.generatedDate(
			 ).plus(
				 _retry
			 ).isAfter(
				 now
			 ))) {

			return Decision.SUMMARIZE;
		}

		return Decision.UP_TO_DATE;
	}

	public static final String STATUS_FAILED = "failed";

	public static final String STATUS_HIDDEN = "hidden";

	public static final String STATUS_READY = "ready";

	public static final String STATUS_SKIPPED = "skipped";

	public enum Decision {

		/**
		 * The topic is flagged and has no summary to hide.
		 */
		FLAGGED,

		/**
		 * The topic is flagged: hide its summary.
		 */
		HIDE,

		NO_LAST_POST_DATE, NOT_QUIET_YET,

		/**
		 * Replies were deleted below the minimum: remove the summary.
		 */
		REMOVE,

		/**
		 * Replies were deleted, or posts edited or answers accepted, since the
		 * summary was made: make a new one, or hide the summary until a new one
		 * can be made.
		 */
		REPLACE,

		SUMMARIZE, TOO_FEW_REPLIES, UP_TO_DATE

	}

	/**
	 * A C2M0Thread entry, as far as the policy needs it.
	 *
	 * @param messageCount the thread's posts, the first post included
	 * @param lastPostDate the thread's lastPostDate, null if unknown
	 * @param lastPostModified when one of its posts was last modified, if
	 *        recently; null otherwise
	 * @param validatedFlagCount the thread's validated reports
	 */
	public record Discussion(
		int messageCount, Instant lastPostDate, Instant lastPostModified,
		int validatedFlagCount) {
	}

	/**
	 * A ForumsAISummary entry, as far as the policy needs it.
	 *
	 * @param messageCount the thread's posts when the summary was made
	 */
	public record Summary(
		long id, Instant lastPostDate, Instant generatedDate, String status,
		int messageCount) {
	}

	private final int _minReplies;
	private final Duration _quietPeriod;
	private final Duration _retry;

}
