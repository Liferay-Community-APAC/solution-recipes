/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.liferay.forums.ai.summary;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Every few minutes: finds the forum discussions that need a summary and
 * starts the Forums AI Summary workflow for each, with the discussion as the
 * agent's request. The workflow's AI Hub agent node runs the summary agent
 * through the forum's AI Hub connection, then its workflow action calls
 * {@link #saveResult(JSONObject)}, which saves the summary in
 * ForumsAISummary. Follows the forum's moderation: hides the summaries of
 * flagged topics, makes a new summary when posts are deleted or edited, and
 * removes summaries whose discussion is gone.
 */
@Component
public class SummaryJob {

	@Scheduled(
		fixedDelayString = "#{${forums.ai.summary.interval.seconds} * 1000}",
		initialDelayString = "30000"
	)
	public void run() {

		// The workflow starts by name and version: its latest deployed one.

		try {
			_workflowDefinitionVersion = _liferayClient.get(
				"/o/headless-admin-workflow/v1.0/workflow-definitions/by-name/" +
					LiferayClient.encode(
						_workflowDefinitionName
					).replace(
						"+", "%20"
					) + "?fields=version"
			).optString(
				"version"
			);
		}
		catch (Exception exception) {
			_log.error(
				"The workflow " + _workflowDefinitionName + " isn't deployed: " +
					_describe(exception));

			return;
		}

		Map<Long, Map<Long, JSONObject>> summariesBySite = new HashMap<>();
		int summarizedToday = 0;

		for (String site : _sites.split(",")) {
			if (site.isBlank()) {
				continue;
			}

			try {
				long siteId = _liferayClient.get(
					"/o/headless-admin-user/v1.0/sites/by-friendly-url-path/" +
						LiferayClient.encode(site.trim())
				).getLong(
					"id"
				);

				Map<Long, JSONObject> summaries = _summaries(siteId);

				summariesBySite.put(siteId, summaries);
				summarizedToday += _countToday(summaries.values());
			}
			catch (Exception exception) {
				_log.error("Site " + site + ": " + _describe(exception));
			}
		}

		// The daily count survives restarts: it's at least the number of
		// summaries saved today.

		LocalDate today = LocalDate.now(ZoneOffset.UTC);

		if (!today.equals(_countDay)) {
			_countDay = today;
			_count = 0;
		}

		_count = Math.max(_count, summarizedToday);

		for (Map.Entry<Long, Map<Long, JSONObject>> entry :
				summariesBySite.entrySet()) {

			try {
				_runSite(entry.getKey(), entry.getValue());
			}
			catch (Exception exception) {
				_log.error(
					"Site " + entry.getKey() + ": " + _describe(exception));
			}
		}
	}

	private static int _countToday(Iterable<JSONObject> summaries) {
		LocalDate today = LocalDate.now(ZoneOffset.UTC);
		int count = 0;

		for (JSONObject summary : summaries) {
			Instant generatedDate = _instant(summary, "generatedDate");

			if ((generatedDate != null) &&
				today.equals(LocalDate.ofInstant(generatedDate, ZoneOffset.UTC)) &&
				!SummaryPolicy.STATUS_HIDDEN.equals(_status(summary))) {

				count++;
			}
		}

		return count;
	}

	private static String _describe(Exception exception) {
		String message = exception.getMessage();

		return exception.getClass(
		).getSimpleName() + ((message == null) ? "" : (": " + message));
	}

	private void _hide(long threadId, JSONObject summary, String reason)
		throws Exception {

		_liferayClient.patch(
			"/o/c/forumsaisummaries/" + summary.getLong("id"),
			new JSONObject(
			).put(
				"summary", ""
			).put(
				"summaryStatus",
				new JSONObject().put("key", SummaryPolicy.STATUS_HIDDEN)
			));

		_log.info("Thread " + threadId + ": summary hidden, " + reason);
	}

	private static Instant _instant(JSONObject json, String key) {
		String value = json.optString(key, "");

		return value.isBlank() ? null : Instant.parse(value);
	}

	/**
	 * When each thread's posts were last modified, for the posts modified in
	 * the last lookback hours: edits, and answers accepted or unaccepted.
	 */
	private Map<Long, Instant> _lastPostModified(long siteId, Instant now)
		throws Exception {

		Instant since = now.minus(
			Duration.ofHours(_lookbackHours)
		).truncatedTo(
			ChronoUnit.SECONDS
		);

		JSONArray items = _liferayClient.getAll(
			"/o/c/c2m0messages/scopes/" + siteId + "?filter=" +
				LiferayClient.encode("dateModified gt " + since) + "&fields=" +
					LiferayClient.encode(
						"dateModified,r_threadMessages_c_c2m0ThreadId"));

		Map<Long, Instant> lastPostModified = new HashMap<>();

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			long threadId = item.optLong("r_threadMessages_c_c2m0ThreadId", 0);
			Instant dateModified = _instant(item, "dateModified");

			if ((threadId > 0) && (dateModified != null)) {
				lastPostModified.merge(
					threadId, dateModified,
					(a, b) -> a.isAfter(b) ? a : b);
			}
		}

		return lastPostModified;
	}

	private List<Post> _posts(long siteId, long threadId) throws Exception {
		JSONArray items = _liferayClient.getAll(
			"/o/c/c2m0messages/scopes/" + siteId + "?filter=" +
				LiferayClient.encode(
					"r_threadMessages_c_c2m0ThreadId eq '" + threadId + "'") +
						"&fields=" +
							LiferayClient.encode(
								"id,body,bodyRawText,format,answer,voteTotal," +
									"r_messageReplies_c_c2m0MessageId,creator," +
										"dateCreated"));

		List<Post> posts = new ArrayList<>();

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			String text = item.optString("bodyRawText", "");

			if (text.isBlank()) {
				text = DiscussionFormatter.htmlToText(item.optString("body", ""));
			}

			JSONObject creator = item.optJSONObject("creator");

			posts.add(
				new Post(
					item.getLong("id"),
					item.optLong("r_messageReplies_c_c2m0MessageId", 0),
					(creator == null) ? "A member" :
						creator.optString("name", "A member"),
					_instant(item, "dateCreated"), text.trim(),
					item.optBoolean("answer"),
					(int)Math.round(item.optDouble("voteTotal", 0))));
		}

		return posts;
	}

	private void _remove(long threadId, JSONObject summary, String reason)
		throws Exception {

		_liferayClient.delete(
			"/o/c/forumsaisummaries/" + summary.getLong("id"));

		_log.info("Thread " + threadId + ": summary removed, " + reason);
	}

	private void _runSite(long siteId, Map<Long, JSONObject> summaries)
		throws Exception {

		Instant now = Instant.now();

		JSONArray threads = _liferayClient.getAll(
			"/o/c/c2m0threads/scopes/" + siteId + "?fields=" +
				LiferayClient.encode(
					"id,externalReferenceCode,title,question,messageCount," +
						"lastPostDate,validatedFlagCount"));

		Map<Long, Instant> lastPostModified = _lastPostModified(siteId, now);

		SummaryPolicy summaryPolicy = new SummaryPolicy(
			_minReplies, Duration.ofMinutes(_quietPeriodMinutes),
			Duration.ofMinutes(_retryMinutes));

		Set<Long> threadIds = new HashSet<>();
		boolean warnedLimit = false;

		for (int i = 0; i < threads.length(); i++) {
			JSONObject thread = threads.getJSONObject(i);

			long threadId = thread.getLong("id");

			threadIds.add(threadId);

			JSONObject summary = summaries.get(threadId);

			SummaryPolicy.Decision decision = summaryPolicy.decide(
				new SummaryPolicy.Discussion(
					_toInt(thread.opt("messageCount")),
					_instant(thread, "lastPostDate"),
					lastPostModified.get(threadId),
					_toInt(thread.opt("validatedFlagCount"))),
				(summary == null) ? null :
					new SummaryPolicy.Summary(
						summary.getLong("id"),
						_instant(summary, "lastPostDate"),
						_instant(summary, "generatedDate"), _status(summary),
						_toInt(summary.opt("messageCount"))),
				now);

			try {
				if (decision == SummaryPolicy.Decision.HIDE) {
					_hide(threadId, summary, "the topic is flagged");
				}
				else if (decision == SummaryPolicy.Decision.REMOVE) {
					_remove(threadId, summary, "too few replies");
				}
				else if ((decision == SummaryPolicy.Decision.REPLACE) ||
						 (decision == SummaryPolicy.Decision.SUMMARIZE)) {

					boolean ready = (summary != null) &&
						SummaryPolicy.STATUS_READY.equals(_status(summary));
					String reason = _waitReason(threadId, now);

					if (reason == null) {
						boolean started = _startWorkflow(siteId, thread);

						// The summary would keep what was edited or deleted
						// until the new one is saved.

						if ((decision == SummaryPolicy.Decision.REPLACE) &&
							ready) {

							_hide(
								threadId, summary,
								started ?
									"posts changed and a new summary is being " +
										"written" :
											"posts changed and a new summary " +
												"failed");
						}
					}
					else {
						if (reason.startsWith("daily limit") && !warnedLimit) {
							_log.info(
								"Daily limit of " + _dailyLimit +
									" summaries reached; the rest wait for " +
										"tomorrow");

							warnedLimit = true;
						}

						if ((decision == SummaryPolicy.Decision.REPLACE) &&
							ready) {

							_hide(
								threadId, summary,
								"posts changed and a new summary waits for the " +
									reason);
						}
					}
				}
			}
			catch (Exception exception) {
				_log.error("Thread " + threadId + ": " + _describe(exception));
			}
		}

		// Summaries of discussions that are gone, or that this service can no
		// longer see.

		for (Map.Entry<Long, JSONObject> entry : summaries.entrySet()) {
			if (!threadIds.contains(entry.getKey())) {
				_remove(
					entry.getKey(), entry.getValue(),
					"the discussion no longer exists");
			}
		}
	}

	private static String _status(JSONObject summary) {
		Object value = summary.opt("summaryStatus");

		if (value instanceof JSONObject) {
			return ((JSONObject)value).optString("key", "");
		}

		return (value == null) ? "" : value.toString();
	}

	private Map<Long, JSONObject> _summaries(long siteId) throws Exception {
		Map<Long, JSONObject> summaries = new HashMap<>();

		JSONArray items = _liferayClient.getAll(
			"/o/c/forumsaisummaries/scopes/" + siteId);

		for (int i = 0; i < items.length(); i++) {
			JSONObject item = items.getJSONObject(i);

			summaries.put(item.getLong("threadId"), item);
		}

		return summaries;
	}

	/**
	 * Saves the summary the Forums AI Summary workflow wrote, from its workflow
	 * action's payload: the workflow's context, with the agent's output.
	 */
	public void saveResult(JSONObject payload) throws Exception {
		Result result = parseResult(payload);

		if (result == null) {
			_log.warn("A workflow action call without a thread was ignored");

			return;
		}

		_pending.remove(result.threadId());

		String status = SummaryPolicy.STATUS_READY;
		String text = result.text();

		if (text.isEmpty() || text.equals("NO_SUMMARY")) {
			status = SummaryPolicy.STATUS_SKIPPED;
			text = "";
		}
		else {
			text = trimSummary(text, _maxSummaryChars);
		}

		_failedAt.remove(result.threadId());

		JSONObject entry = new JSONObject();

		entry.put(
			"agentExternalReferenceCode",
			result.agentExternalReferenceCode());

		// Liferay's date-time fields don't take fractions of a second.

		entry.put(
			"generatedDate",
			Instant.now(
			).truncatedTo(
				ChronoUnit.SECONDS
			).toString());
		entry.put("lastPostDate", result.lastPostDate());

		// The thread's own count, which the policy compares to find deleted
		// replies.

		entry.put("messageCount", result.messageCount());
		entry.put("summary", text);
		entry.put("summaryStatus", new JSONObject().put("key", status));
		entry.put(
			"threadExternalReferenceCode",
			result.threadExternalReferenceCode());
		entry.put("threadId", result.threadId());

		String erc = "FORUMS_AI_SUMMARY_" + result.threadId();

		boolean exists = true;

		try {
			_liferayClient.get(
				"/o/c/forumsaisummaries/scopes/" + result.siteId() +
					"/by-external-reference-code/" + erc + "?fields=id");
		}
		catch (JsonHttp.HttpException httpException) {
			if (httpException.getStatus() != 404) {
				throw httpException;
			}

			exists = false;
		}

		JSONObject saved = _liferayClient.put(
			"/o/c/forumsaisummaries/scopes/" + result.siteId() +
				"/by-external-reference-code/" + erc,
			entry);

		if (!exists) {

			// Readers see a summary as they see the discussion: the forum
			// gives the User role VIEW on its threads and posts.

			_liferayClient.put(
				"/o/c/forumsaisummaries/" + saved.getLong("id") + "/permissions",
				new JSONArray(
				).put(
					new JSONObject(
					).put(
						"actionIds", new JSONArray().put("VIEW")
					).put(
						"roleName", "User"
					)
				));
		}

		_log.info(
			"Thread " + result.threadId() + ": " + status + ", saved from the " +
				"workflow");
	}

	/**
	 * The summary in a workflow action's payload, or null if it names no
	 * thread. The workflow's context values are at the payload's top level:
	 * those this service started the workflow with, and the agent's output,
	 * under its output variable (summary) and as output.
	 */
	static Result parseResult(JSONObject payload) {
		long threadId = payload.optLong(CONTEXT_PREFIX + "ThreadId", 0);
		long siteId = payload.optLong(CONTEXT_PREFIX + "SiteId", 0);

		if ((threadId <= 0) || (siteId <= 0)) {
			return null;
		}

		String text = payload.optString("summary", "");

		if (text.isBlank()) {
			text = payload.optString("output", "");
		}

		return new Result(
			payload.optString("agentDefinitionExternalReferenceCode", ""),
			payload.optString(CONTEXT_PREFIX + "LastPostDate", ""),
			_toInt(payload.opt(CONTEXT_PREFIX + "MessageCount")), siteId,
			text.trim(),
			payload.optString(CONTEXT_PREFIX + "ThreadExternalReferenceCode", ""),
			threadId);
	}

	/**
	 * Starts the Forums AI Summary workflow for a discussion, with the
	 * discussion as the agent's request and what saving the summary needs.
	 *
	 * @return whether the workflow started
	 */
	private boolean _startWorkflow(long siteId, JSONObject thread)
		throws Exception {

		long threadId = thread.getLong("id");
		List<Post> posts = _posts(siteId, threadId);

		String input = DiscussionFormatter.format(
			thread.optString("title", ""), thread.optBoolean("question"), posts,
			_maxInputChars);

		_count++;

		JSONObject context = new JSONObject(
		).put(
			"request", input
		).put(
			CONTEXT_PREFIX + "LastPostDate", thread.optString("lastPostDate")
		).put(
			CONTEXT_PREFIX + "MessageCount", _toInt(thread.opt("messageCount"))
		).put(
			CONTEXT_PREFIX + "SiteId", siteId
		).put(
			CONTEXT_PREFIX + "ThreadExternalReferenceCode",
			thread.optString("externalReferenceCode")
		).put(
			CONTEXT_PREFIX + "ThreadId", threadId
		);

		try {
			JSONObject workflowInstance = _liferayClient.post(
				"/o/headless-admin-workflow/v1.0/workflow-instances/submit",
				new JSONObject(
				).put(
					"context", context
				).put(
					"siteId", siteId
				).put(
					"workflowDefinitionName", _workflowDefinitionName
				).put(
					"workflowDefinitionVersion", _workflowDefinitionVersion
				));

			_pending.put(
				threadId,
				new Pending(workflowInstance.optLong("id"), Instant.now()));

			_log.info(
				"Thread " + threadId + ": workflow " +
					workflowInstance.optLong("id") + " started (" +
						posts.size() + " posts, " + input.length() +
							" input characters)");

			return true;
		}
		catch (Exception exception) {
			_failedAt.put(threadId, Instant.now());

			_log.error(
				"Thread " + threadId + ": the workflow " +
					_workflowDefinitionName + " didn't start: " +
						_describe(exception));

			return false;
		}
	}

	/**
	 * Aggregation fields, such as messageCount, come back as strings.
	 */
	private static int _toInt(Object value) {
		if (value instanceof Number) {
			return ((Number)value).intValue();
		}

		try {
			return (value == null) ? 0 :
				(int)Double.parseDouble(value.toString());
		}
		catch (NumberFormatException numberFormatException) {
			return 0;
		}
	}

	/**
	 * Cuts a summary longer than maxChars at the last sentence that fits, or
	 * at maxChars with an ellipsis when that sentence ends in the first half.
	 */
	static String trimSummary(String text, int maxChars) {
		if (text.length() <= maxChars) {
			return text;
		}

		String cut = text.substring(0, maxChars);

		int end = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf(".\n"));

		return (end > (maxChars / 2)) ? cut.substring(0, end + 1) :
			cut.trim() + "…";
	}

	/**
	 * Why a summary can't be made now, or null if it can: a workflow started
	 * for it less than the retry period ago hasn't saved it yet, a workflow
	 * failed to start less than the retry period ago, or the daily limit is
	 * reached.
	 */
	private String _waitReason(long threadId, Instant now) {
		Pending pending = _pending.get(threadId);

		if (pending != null) {
			if (pending.startedAt(
				).plus(
					Duration.ofMinutes(_retryMinutes)
				).isAfter(
					now
				)) {

				return "workflow that is writing it";
			}

			_pending.remove(threadId);

			// A workflow whose AI Hub agent node failed stays in that node:
			// delete it, so failed runs don't pile up in Workflow, Submissions.

			try {
				_liferayClient.delete(
					"/o/headless-admin-workflow/v1.0/workflow-instances/" +
						pending.workflowInstanceId());
			}
			catch (Exception exception) {
				_log.warn(
					"Thread " + threadId + ": unable to delete the workflow " +
						pending.workflowInstanceId() + ": " +
							_describe(exception));
			}

			_log.warn(
				"Thread " + threadId + ": the workflow " +
					pending.workflowInstanceId() + " didn't save a summary " +
						"within " + _retryMinutes + " minutes; starting it again");
		}

		Instant failedAt = _failedAt.get(threadId);

		if ((failedAt != null) &&
			failedAt.plus(
				Duration.ofMinutes(_retryMinutes)
			).isAfter(
				now
			)) {

			return "retry after a failure";
		}

		if (_count >= _dailyLimit) {
			return "daily limit";
		}

		return null;
	}

	/**
	 * The workflow context keys this service starts the workflow with.
	 */
	static final String CONTEXT_PREFIX = "forumsAISummary";

	private static final Log _log = LogFactory.getLog(SummaryJob.class);

	private int _count;
	private LocalDate _countDay;

	@Value("${forums.ai.summary.daily.limit}")
	private int _dailyLimit;

	private final Map<Long, Instant> _failedAt = new ConcurrentHashMap<>();

	@Autowired
	private LiferayClient _liferayClient;

	@Value("${forums.ai.summary.edit.lookback.hours}")
	private int _lookbackHours;

	@Value("${forums.ai.summary.max.input.chars}")
	private int _maxInputChars;

	@Value("${forums.ai.summary.max.summary.chars}")
	private int _maxSummaryChars;

	@Value("${forums.ai.summary.min.replies}")
	private int _minReplies;

	@Value("${forums.ai.summary.quiet.period.minutes}")
	private int _quietPeriodMinutes;

	@Value("${forums.ai.summary.retry.minutes}")
	private int _retryMinutes;

	private final Map<Long, Pending> _pending = new ConcurrentHashMap<>();

	@Value("${forums.ai.summary.sites}")
	private String _sites;

	@Value("${forums.ai.summary.workflow.definition.name}")
	private String _workflowDefinitionName;

	private String _workflowDefinitionVersion;

	private record Pending(long workflowInstanceId, Instant startedAt) {
	}

	record Result(
		String agentExternalReferenceCode, String lastPostDate, int messageCount,
		long siteId, String text, String threadExternalReferenceCode,
		long threadId) {
	}

}
