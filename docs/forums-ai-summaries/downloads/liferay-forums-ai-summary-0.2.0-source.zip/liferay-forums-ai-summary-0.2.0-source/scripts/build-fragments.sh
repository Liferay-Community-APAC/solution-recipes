#!/usr/bin/env bash
# SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
# SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
# Builds the fragment collection zip that administrators import in Design > Fragments:
# fragments/dist/liferay-forums-ai-summary-fragments.zip, with the collection folder at its root.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/fragments/dist"
rm -f "$ROOT/fragments/dist/liferay-forums-ai-summary-fragments.zip"
(cd "$ROOT/fragments" && zip -qrX dist/liferay-forums-ai-summary-fragments.zip forums-ai-summary)
echo "Built fragments/dist/liferay-forums-ai-summary-fragments.zip"
