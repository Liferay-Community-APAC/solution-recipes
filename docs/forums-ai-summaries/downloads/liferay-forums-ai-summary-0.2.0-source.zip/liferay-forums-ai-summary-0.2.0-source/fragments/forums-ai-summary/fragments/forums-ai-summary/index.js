/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

const root = fragmentElement.querySelector('.forums-ai-summary');
const card = root.querySelector('.forums-ai-summary__card');
const text = root.querySelector('.forums-ai-summary__text');
const toggle = root.querySelector('.forums-ai-summary__toggle');
const meta = root.querySelector('.forums-ai-summary__meta');

/* The discussion's external reference code: this fragment's own mapped field,
   or else the one the forum's Forums Message Detail fragment maps on the same
   display page. */
function getThreadExternalReferenceCode() {
	const own = root.querySelector('.forums-ai-summary__erc');
	const ownValue = own ? own.textContent.trim() : '';

	if (ownValue && ownValue !== 'Mappable Thread ERC') {
		return ownValue;
	}

	const forum = document.getElementById('forumsDetailERC');
	const forumValue = forum ? forum.textContent.trim() : '';

	if (forumValue && forumValue !== 'Mappable Message ERC') {
		return forumValue;
	}

	return null;
}

function formatDate(value) {
	try {
		return new Intl.DateTimeFormat(root.dataset.languageId || undefined, {
			dateStyle: 'medium',
		}).format(new Date(value));
	}
	catch (error) {
		return value.slice(0, 10);
	}
}

function render(summary) {

	/* Plain text only: each line becomes a paragraph set with textContent, so
	   nothing in a summary can add markup, links or scripts. */

	text.textContent = '';

	summary.summary
		.split(/\n+/)
		.map((line) => line.trim())
		.filter(Boolean)
		.forEach((line) => {
			const paragraph = document.createElement('p');

			paragraph.textContent = line;
			text.appendChild(paragraph);
		});

	const replies = Math.max(0, (parseInt(summary.messageCount, 10) || 1) - 1);

	meta.textContent = (root.dataset.metaTemplate || '')
		.replace('{date}', formatDate(summary.generatedDate))
		.replace('{replies}', String(replies));

	card.hidden = false;

	/* Collapsed to a few lines, with Show More when there is more. */

	text.classList.add('forums-ai-summary__text--collapsed');

	if (text.scrollHeight > text.clientHeight + 1) {
		toggle.hidden = false;

		toggle.addEventListener('click', () => {
			const expanded = toggle.getAttribute('aria-expanded') === 'true';

			text.classList.toggle('forums-ai-summary__text--collapsed', expanded);
			toggle.setAttribute('aria-expanded', String(!expanded));
			toggle.textContent = expanded
				? root.dataset.moreLabel
				: root.dataset.lessLabel;
		});
	}
}

function load() {
	const externalReferenceCode = getThreadExternalReferenceCode();

	if (!externalReferenceCode || !window.Liferay || !Liferay.Util) {
		return;
	}

	const filter =
		"threadExternalReferenceCode eq '" +
		externalReferenceCode.replace(/'/g, "''") +
		"'";

	Liferay.Util.fetch(
		'/o/c/forumsaisummaries/scopes/' +
			root.dataset.siteId +
			'?pageSize=1&fields=summary,summaryStatus,generatedDate,messageCount&filter=' +
			encodeURIComponent(filter)
	)
		.then((response) => (response.ok ? response.json() : null))
		.then((json) => {
			const summary = json && json.items && json.items[0];

			if (
				summary &&
				summary.summary &&
				summary.summaryStatus &&
				summary.summaryStatus.key === 'ready'
			) {
				render(summary);
			}
		})
		.catch(() => {

			/* No summary is shown; the page works as before. */

		});
}

if (layoutMode === 'edit') {
	root.querySelector('.forums-ai-summary__placeholder').hidden = false;

	/* Shown in the editor only, so the field can be selected and mapped. */

	root.querySelector('.forums-ai-summary__erc').style.display = 'block';
}
else if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', load);
}
else {
	load();
}
